/********************************************************
 * ADO.NET 2.0 Data Provider for SQLite Version 3.X
 * Written by Joe Mistachkin (joe@mistachkin.com)
 *
 * Released to the public domain, use at your own risk!
 ********************************************************/

using System.Data.SQLite;

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceId("1911e60e5ee59d01f841dbe35dfd8e5104eae8c8")]

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceTimeStamp("2020-05-30 14:28:05 UTC")]
