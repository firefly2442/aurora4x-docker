/********************************************************
 * ADO.NET 2.0 Data Provider for SQLite Version 3.X
 * Written by Joe Mistachkin (joe@mistachkin.com)
 *
 * Released to the public domain, use at your own risk!
 ********************************************************/

using System.Data.SQLite;

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceId("cc88c047df08636d7ebdc78e746a3ecf8145f434")]

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceTimeStamp("2023-06-09 21:00:51 UTC")]
